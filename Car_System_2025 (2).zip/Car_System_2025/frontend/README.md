# React + Vite

This template provides a minimal setup to get React working. 
